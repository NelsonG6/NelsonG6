function openPage(pageName, elmnt, color) {
  // Hide all elements with class="tabcontent" by default */
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Remove the background color of all tablinks/buttons
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }

  // Show the specific tab content
  document.getElementById(pageName).style.display = "block";

  // Add the specific color to the button used to open the tab content
  elmnt.style.backgroundColor = color;

  var v_tabs = document.getElementsByClassName(pageName);
  var i;
  for(i = 0; i < v_tabs.length; i++)
  {
    if(v_tabs[i].classList.contains("defaultOpen"))
    {
      v_tabs[i].click();
    }
  }
}

document.getElementById("defaultOpenHTab").click();